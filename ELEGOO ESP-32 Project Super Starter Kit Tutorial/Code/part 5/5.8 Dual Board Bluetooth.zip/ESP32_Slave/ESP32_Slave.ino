#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SERVICE_UUID           "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID_RX "beb5483e-36e1-4688-b7f5-ea07361b26a8"
#define CHARACTERISTIC_UUID_TX "8d8f28a9-467b-4f25-a019-7cc5e6c8f721"

#define LED_PIN 2

BLEServer *pServer = nullptr;
BLECharacteristic *pTxCharacteristic = nullptr;
bool deviceConnected = false;

// Send a message to Master via BLE Notify
void sendViaBLE(const String &msg) {
  if (deviceConnected && pTxCharacteristic != nullptr) {
    pTxCharacteristic->setValue((msg + "\n").c_str());
    pTxCharacteristic->notify();
    delay(10);
  }
}

// Handle commands entered locally or received from Master
// Returns true if the message was a recognized command
bool handleCommand(const String &msg, const String &source) {
  if (msg == "/ledon") {
    if (source == "Local") {
      // Local input: control ONLY the remote (Master) LED, not local
      sendViaBLE("/ledon");
      Serial.println("[Slave] >>> Sent command: turn Master LED ON");
    } else {
      // Received from Master: control OUR (Slave) LED
      digitalWrite(LED_PIN, HIGH);
      Serial.println("[Slave] >>> Master command: LED turned ON");
      sendViaBLE("[Slave] LED turned ON");
    }
    return true;
  }
  if (msg == "/ledoff") {
    if (source == "Local") {
      sendViaBLE("/ledoff");
      Serial.println("[Slave] >>> Sent command: turn Master LED OFF");
    } else {
      digitalWrite(LED_PIN, LOW);
      Serial.println("[Slave] >>> Master command: LED turned OFF");
      sendViaBLE("[Slave] LED turned OFF");
    }
    return true;
  }
  if (msg == "/help") {
    if (source == "Local") {
      sendViaBLE("/help");
    } else {
      sendViaBLE("[Slave] Commands: /ledon  /ledoff  /help");
    }
    return true;
  }
  return false;
}

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *pServer) {
    deviceConnected = true;
    Serial.println("[Slave] >>> Master connected!");
  }
  void onDisconnect(BLEServer *pServer) {
    deviceConnected = false;
    Serial.println("[Slave] <<< Master disconnected. Restarting advertising...");
    BLEDevice::startAdvertising();
  }
};

class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String msg = pCharacteristic->getValue();
    msg.trim();
    if (msg.length() > 0) {
      if (!handleCommand(msg, "Master")) {
        if (msg.startsWith("/")) {
          Serial.print("[Slave] Unknown command from Master: ");
          Serial.println(msg);
          sendViaBLE("[Slave] Unknown command. Try: /ledon /ledoff /help");
        } else {
          Serial.print("[Slave] Received: ");
          Serial.println(msg);
        }
      }
    }
  }
};

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);

  Serial.println();
  Serial.println("========================================");
  Serial.println("  ESP32 BLE Slave — Starting up...");
  Serial.println("========================================");

  BLEDevice::init("ESP32_BLE_Slave");
  BLEDevice::setMTU(512);

  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new ServerCallbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);

  pTxCharacteristic = pService->createCharacteristic(
    CHARACTERISTIC_UUID_TX, BLECharacteristic::PROPERTY_NOTIFY);
  pTxCharacteristic->addDescriptor(new BLE2902());

  // RX supports both Write and Write Without Response
  BLECharacteristic *pRxCharacteristic = pService->createCharacteristic(
    CHARACTERISTIC_UUID_RX,
    BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  pRxCharacteristic->setCallbacks(new RxCallbacks());

  pService->start();

  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->start();

  Serial.println("[Slave] BLE device name: ESP32_BLE_Slave");
  Serial.println("[Slave] Advertising started. Waiting for Master connection...");
  Serial.println();
  Serial.println("[Slave] Type a message and press Enter to send to Master.");
  Serial.println("[Slave] Commands: /ledon  /ledoff  /help");
}

void loop() {
  if (Serial.available()) {
    String msg = Serial.readStringUntil('\n');
    msg.trim();
    if (msg.length() > 0) {
      if (!handleCommand(msg, "Local")) {
        if (msg.startsWith("/")) {
          Serial.print("[Slave] Unknown command: ");
          Serial.println(msg);
          Serial.println("[Slave] Available: /ledon  /ledoff  /help");
        } else {
          if (deviceConnected) {
            sendViaBLE(msg);
            Serial.print("[Slave] Sent: ");
            Serial.println(msg);
          } else {
            Serial.println("[Slave] Not connected. Wait for Master to connect first.");
          }
        }
      }
    }
  }
  delay(10);
}
