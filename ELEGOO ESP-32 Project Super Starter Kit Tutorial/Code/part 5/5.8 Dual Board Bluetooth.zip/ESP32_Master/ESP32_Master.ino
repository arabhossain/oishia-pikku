#include <BLEDevice.h>
#include <BLEScan.h>
#include <BLEClient.h>
#include <BLERemoteCharacteristic.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SERVICE_UUID           "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID_RX "beb5483e-36e1-4688-b7f5-ea07361b26a8"
#define CHARACTERISTIC_UUID_TX "8d8f28a9-467b-4f25-a019-7cc5e6c8f721"

#define LED_PIN 2

BLEClient *pClient = nullptr;
BLEScan *pScan = nullptr;
BLERemoteCharacteristic *pTxCharacteristic = nullptr;
BLERemoteCharacteristic *pRxCharacteristic = nullptr;

bool deviceConnected = false;
bool shouldConnect = false;
bool scanDone = false;
BLEAdvertisedDevice *targetDevice = nullptr;

// Send a message to Slave via BLE Write (Write Command, no response)
void sendViaBLE(const String &msg) {
  if (deviceConnected && pRxCharacteristic != nullptr) {
    String packet = msg + "\n";
    pRxCharacteristic->writeValue(packet, false);
    delay(10);
  }
}

// Handle commands entered locally or received from Slave
// Returns true if the message was a recognized command
bool handleCommand(const String &msg, const String &source) {
  if (msg == "/ledon") {
    if (source == "Local") {
      // Local input: control ONLY the remote (Slave) LED, not local
      sendViaBLE("/ledon");
      Serial.println("[Master] >>> Sent command: turn Slave LED ON");
    } else {
      // Received from Slave: control OUR (Master) LED
      digitalWrite(LED_PIN, HIGH);
      Serial.println("[Master] >>> Slave command: LED turned ON");
    }
    return true;
  }
  if (msg == "/ledoff") {
    if (source == "Local") {
      sendViaBLE("/ledoff");
      Serial.println("[Master] >>> Sent command: turn Slave LED OFF");
    } else {
      digitalWrite(LED_PIN, LOW);
      Serial.println("[Master] >>> Slave command: LED turned OFF");
    }
    return true;
  }
  if (msg == "/help") {
    if (source == "Local") {
      sendViaBLE("/help");
    } else {
      Serial.println("[Master] Slave says: /ledon /ledoff /help");
    }
    return true;
  }
  return false;
}

class ClientCallbacks : public BLEClientCallbacks {
  void onConnect(BLEClient *pClient) {
    deviceConnected = true;
    Serial.println("[Master] >>> Connected to Slave!");
  }
  void onDisconnect(BLEClient *pClient) {
    deviceConnected = false;
    Serial.println("[Master] <<< Disconnected from Slave. Reconnecting...");
    shouldConnect = true;
  }
};

class ScanCallbacks : public BLEAdvertisedDeviceCallbacks {
  void onResult(BLEAdvertisedDevice advertisedDevice) {
    if (advertisedDevice.haveServiceUUID() &&
        advertisedDevice.getServiceUUID().toString() == SERVICE_UUID) {
      Serial.print("[Master] Found target device: ");
      Serial.println(advertisedDevice.getName());
      targetDevice = new BLEAdvertisedDevice(advertisedDevice);
      pScan->stop();
      scanDone = true;
    }
  }
};

// Called when Slave sends a notification (Slave -> Master)
void notifyCallback(BLERemoteCharacteristic *pCharacteristic,
                     uint8_t *data, size_t length, bool isNotify) {
  String msg = "";
  for (size_t i = 0; i < length; i++) {
    msg += (char)data[i];
  }
  msg.trim();
  if (msg.length() > 0) {
    if (!handleCommand(msg, "Slave")) {
      if (msg.startsWith("[Slave]")) {
        Serial.println("[Master] " + msg);
      } else if (msg.startsWith("/")) {
        Serial.print("[Master] Unknown command from Slave: ");
        Serial.println(msg);
      } else {
        Serial.print("[Master] Received: ");
        Serial.println(msg);
      }
    }
  }
}

bool connectToSlave() {
  if (targetDevice == nullptr) {
    Serial.println("[Master] No target device found.");
    return false;
  }

  pClient = BLEDevice::createClient();
  pClient->setClientCallbacks(new ClientCallbacks());

  Serial.print("[Master] Connecting to ");
  Serial.println(targetDevice->getName());

  if (!pClient->connect(targetDevice)) {
    Serial.println("[Master] Connection failed.");
    return false;
  }

  Serial.println("[Master] Connected! Discovering services...");

  BLERemoteService *pService = pClient->getService(SERVICE_UUID);
  if (pService == nullptr) {
    Serial.println("[Master] Service not found.");
    pClient->disconnect();
    return false;
  }

  Serial.println("[Master] Service found! Discovering characteristics...");

  pTxCharacteristic = pService->getCharacteristic(CHARACTERISTIC_UUID_TX);
  if (pTxCharacteristic == nullptr) {
    Serial.println("[Master] TX characteristic not found.");
    pClient->disconnect();
    return false;
  }

  pRxCharacteristic = pService->getCharacteristic(CHARACTERISTIC_UUID_RX);
  if (pRxCharacteristic == nullptr) {
    Serial.println("[Master] RX characteristic not found.");
    pClient->disconnect();
    return false;
  }

  if (pTxCharacteristic->canNotify()) {
    pTxCharacteristic->registerForNotify(notifyCallback);
    Serial.println("[Master] Subscribed to Slave notifications.");
  }

  Serial.println("[Master] Ready! Type a message and press Enter to send.");
  return true;
}

void startScan() {
  pScan = BLEDevice::getScan();
  pScan->setAdvertisedDeviceCallbacks(new ScanCallbacks());
  pScan->setActiveScan(true);
  pScan->start(0, false);
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);

  Serial.println();
  Serial.println("========================================");
  Serial.println("  ESP32 BLE Master — Starting up...");
  Serial.println("========================================");

  BLEDevice::init("ESP32_BLE_Master");
  BLEDevice::setMTU(512);

  Serial.println("[Master] Scanning for ESP32_BLE_Slave...");
  startScan();
}

void loop() {
  if (scanDone) {
    scanDone = false;
    if (connectToSlave()) {
      shouldConnect = false;
    } else {
      shouldConnect = true;
    }
  }

  if (shouldConnect && !deviceConnected) {
    shouldConnect = false;
    if (targetDevice != nullptr) {
      connectToSlave();
    } else {
      Serial.println("[Master] Rescanning...");
      startScan();
    }
  }

  if (Serial.available()) {
    String msg = Serial.readStringUntil('\n');
    msg.trim();
    if (msg.length() > 0) {
      if (!handleCommand(msg, "Local")) {
        if (msg.startsWith("/")) {
          Serial.print("[Master] Unknown command: ");
          Serial.println(msg);
          Serial.println("[Master] Available: /ledon  /ledoff  /help");
        } else {
          if (deviceConnected) {
            sendViaBLE(msg);
            Serial.print("[Master] Sent: ");
            Serial.println(msg);
          } else {
            Serial.println("[Master] Not connected. Waiting for Slave...");
          }
        }
      }
    }
  }

  delay(10);
}
