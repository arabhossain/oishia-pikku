/**
 * ESP32 Dual-Board WiFi TCP Communication — CLIENT
 * =================================================
 * This ESP32 connects to the Server's WiFi hotspot,
 * establishes a TCP connection, and can chat bidirectionally
 * via serial input.
 *
 * Hardware: ESP32 Dev Module x1 (Client)
 *   - GPIO2: Onboard LED (on when connected to server)
 *
 * Communication Flow:
 *   1. Client connects to Server's AP "ESP32_Server"
 *   2. Client connects to TCP server at 192.168.4.1:8080
 *   3. Both sides can type messages in serial monitor to send
 *   4. Both sides display received messages
 */

#include <WiFi.h>

// ==================== Configuration ====================
const char* serverSSID = "ESP32_Server";         // Server's hotspot name
const char* serverPassword = "12345678";          // Server's hotspot password
const char* serverIP = "192.168.4.1";             // Server's AP IP address
const uint16_t serverPort = 8080;                 // TCP server port

// ==================== Pins ====================
#define LED_PIN 2

// ==================== State ====================
WiFiClient client;
bool clientConnected = false;
unsigned long lastReconnectAttempt = 0;

void connectToServer() {
  Serial.print("[CLIENT] Connecting to AP: ");
  Serial.println(serverSSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(serverSSID, serverPassword);

  // Wait for WiFi connection (timeout: 15 seconds)
  int timeout = 0;
  while (WiFi.status() != WL_CONNECTED && timeout < 30) {
    delay(500);
    Serial.print(".");
    timeout++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.println("[CLIENT] WiFi connected!");
    Serial.print("[CLIENT] Client IP: ");
    Serial.println(WiFi.localIP());
    Serial.print("[CLIENT] Server IP: ");
    Serial.println(serverIP);

    // Connect to TCP server
    Serial.print("[CLIENT] Connecting to TCP server...");
    if (client.connect(serverIP, serverPort)) {
      clientConnected = true;
      digitalWrite(LED_PIN, HIGH);
      Serial.println(" CONNECTED!");
      Serial.println("[CLIENT] Ready to chat. Type a message and press Enter.");

      // Read welcome message from server
      delay(500);
      while (client.available()) {
        String line = client.readStringUntil('\n');
        if (line.length() > 0) {
          Serial.print("[CLIENT] Server says: ");
          Serial.println(line);
        }
      }
    } else {
      Serial.println(" FAILED!");
      clientConnected = false;
    }
  } else {
    Serial.println();
    Serial.println("[CLIENT] WiFi connection FAILED. Will retry...");
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.println();
  Serial.println("========================================");
  Serial.println("  ESP32 TCP Client — Starting up...");
  Serial.println("========================================");

  connectToServer();
  lastReconnectAttempt = millis();
}

void loop() {
  // Check if still connected
  if (!clientConnected || !client.connected()) {
    clientConnected = false;
    digitalWrite(LED_PIN, LOW);

    // Attempt reconnect every 3 seconds
    if (millis() - lastReconnectAttempt > 3000) {
      lastReconnectAttempt = millis();
      Serial.println("[CLIENT] Attempting to reconnect...");
      client.stop();
      WiFi.disconnect();
      connectToServer();
    }
    return;
  }

  // 1. Read from serial input and send to server
  if (Serial.available()) {
    String msg = Serial.readStringUntil('\n');
    msg.trim();
    if (msg.length() > 0) {
      client.println(msg);
      Serial.print("[CLIENT] Sent: ");
      Serial.println(msg);
    }
  }

  // 2. Read from server and display
  if (client.available()) {
    String msg = client.readStringUntil('\n');
    if (msg.length() > 0) {
      msg.trim();
      Serial.print("[CLIENT] Received: ");
      Serial.println(msg);
    }
  }

  delay(10);  // Small delay to avoid busy loop
}
