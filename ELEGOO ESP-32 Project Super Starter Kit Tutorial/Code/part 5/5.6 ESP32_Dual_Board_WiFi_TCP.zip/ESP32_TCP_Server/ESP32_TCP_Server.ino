/**
 * ESP32 Dual-Board WiFi TCP Communication — SERVER
 * =================================================
 * This ESP32 creates a WiFi hotspot and runs a TCP server.
 * The other ESP32 (client) connects to this hotspot and
 * they can chat bidirectionally via serial input.
 *
 * Hardware: ESP32 Dev Module x1 (Server)
 *   - GPIO2: Onboard LED (on when client connected)
 *
 * Communication Flow:
 *   1. Server creates AP hotspot "ESP32_Server"
 *   2. Client connects to the AP
 *   3. Client connects to TCP server at 192.168.4.1:8080
 *   4. Both sides can type messages in serial monitor to send
 *   5. Both sides display received messages
 */

#include <WiFi.h>

// ==================== Configuration ====================
const char* ap_ssid     = "ESP32_Server";      // Hotspot name
const char* ap_password = "12345678";           // Hotspot password (min 8 chars)
const uint16_t serverPort = 8080;               // TCP server port

// ==================== LED ====================
#define LED_PIN 2

// ==================== TCP Server ====================
WiFiServer server(serverPort);
WiFiClient client;          // Persistent client object
bool clientConnected = false;

void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.println();
  Serial.println("========================================");
  Serial.println("  ESP32 TCP Server — Starting up...");
  Serial.println("========================================");

  // Step 1: Create WiFi hotspot
  Serial.print("[SERVER] Creating AP hotspot: ");
  Serial.println(ap_ssid);
  WiFi.mode(WIFI_AP);
  WiFi.softAP(ap_ssid, ap_password);
  delay(1000);

  Serial.print("[SERVER] AP IP Address: ");
  Serial.println(WiFi.softAPIP());

  // Step 2: Start TCP server
  server.begin();
  Serial.print("[SERVER] TCP Server started on port: ");
  Serial.println(serverPort);
  Serial.println("[SERVER] Waiting for client connection...");
  Serial.println();
  Serial.println("[SERVER] Type a message and press Enter to send.");
  Serial.println();
}

void loop() {
  // Check for incoming client connections (non-blocking)
  if (!clientConnected) {
    WiFiClient newClient = server.available();
    if (newClient) {
      client = newClient;
      clientConnected = true;
      digitalWrite(LED_PIN, HIGH);
      Serial.println("----------------------------------------");
      Serial.println("[SERVER] >>> New client connected!");
      Serial.print("[SERVER] Client IP: ");
      Serial.println(client.remoteIP());

      // Send welcome message to client
      client.println("[Server] Client connected! Ready to chat.");
      Serial.println("[SERVER] Ready to chat. Type a message and press Enter.");
      Serial.println("----------------------------------------");
    }
  }

  // When connected, handle bidirectional communication
  if (clientConnected) {
    // Check if client disconnected
    if (!client.connected()) {
      clientConnected = false;
      digitalWrite(LED_PIN, LOW);
      client.stop();
      Serial.println("----------------------------------------");
      Serial.println("[SERVER] <<< Client disconnected.");
      Serial.println("[SERVER] Waiting for next client...");
      Serial.println("----------------------------------------");
      return;
    }

    // 1. Read from serial input and send to client
    if (Serial.available()) {
      String msg = Serial.readStringUntil('\n');
      msg.trim();
      if (msg.length() > 0) {
        client.println(msg);
        Serial.print("[SERVER] Sent: ");
        Serial.println(msg);
      }
    }

    // 2. Read from client and display
    if (client.available()) {
      String msg = client.readStringUntil('\n');
      if (msg.length() > 0) {
        msg.trim();
        Serial.print("[SERVER] Received: ");
        Serial.println(msg);
      }
    }
  }

  delay(10);  // Small delay to avoid busy loop
}
