/*
 * ESP32 BLE Chat + LED Control (Web Bluetooth)
 *
 * ESP32 acts as a BLE peripheral using a Nordic UART-like service.
 * A web page (Web Bluetooth API) connects to it for:
 *   - Bidirectional chat (web <-> ESP32 serial monitor)
 *   - LED on/off control via /ledon, /ledoff commands
 *
 * Flow:
 *   - Serial monitor input  -> sent to web page via BLE notify
 *   - Web page input        -> shown on serial monitor
 *   - Web /ledon, /ledoff   -> control ESP32 onboard LED (GPIO2)
 *   - Serial /ledon, /ledoff -> also control LED locally
 *
 * Note: Web Bluetooth API only supports BLE, NOT Classic Bluetooth SPP.
 *       So this sketch uses BLE, not BluetoothSerial.
 */

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// ==================== BLE UART Service UUIDs (Nordic UART Service) ====================
#define SERVICE_UUID           "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define CHARACTERISTIC_UUID_RX "6e400003-b5a3-f393-e0a9-e50e24dcca9e"  // Write  (Web -> ESP32)
#define CHARACTERISTIC_UUID_TX "6e400002-b5a3-f393-e0a9-e50e24dcca9e"  // Notify (ESP32 -> Web)

// ==================== LED ====================
#define LED_PIN 2              // Onboard LED, controlled by /ledon and /ledoff commands

// ==================== BLE State ====================
BLEServer *pServer = nullptr;
BLECharacteristic *pTxCharacteristic = nullptr;
bool deviceConnected = false;

// ==================== Helper: send a message to the web page via BLE notify ====================
void sendViaBLE(const String &msg) {
  if (deviceConnected && pTxCharacteristic != nullptr) {
    pTxCharacteristic->setValue((msg + "\n").c_str());
    pTxCharacteristic->notify();
    delay(10);  // Give the BLE stack time to send
  }
}

// ==================== Handle a command string, returns true if it was a command ====================
bool handleCommand(const String &msg, const String &source) {
  if (msg == "/ledon") {
    digitalWrite(LED_PIN, HIGH);
    Serial.println("[BLE] >>> " + source + " command: LED turned ON");
    sendViaBLE("[ESP32] LED turned ON");
    return true;
  }
  if (msg == "/ledoff") {
    digitalWrite(LED_PIN, LOW);
    Serial.println("[BLE] >>> " + source + " command: LED turned OFF");
    sendViaBLE("[ESP32] LED turned OFF");
    return true;
  }
  if (msg == "/help") {
    String help = "[ESP32] Commands: /ledon  /ledoff  /help";
    Serial.println("[BLE] >>> " + source + " command: /help");
    sendViaBLE(help);
    return true;
  }
  return false;
}

// ==================== BLE Server callbacks (connect / disconnect) ====================
class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *pServer) {
    deviceConnected = true;
    Serial.println("[BLE] >>> Web client connected!");
  }

  void onDisconnect(BLEServer *pServer) {
    deviceConnected = false;
    Serial.println("[BLE] <<< Web client disconnected. Restarting advertising...");
    BLEDevice::startAdvertising();
  }
};

// ==================== RX Characteristic callbacks (data arriving from web page) ====================
class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String rxValue = pCharacteristic->getValue();
    if (rxValue.length() == 0) return;

    String msg = rxValue;
    msg.trim();
    if (msg.length() == 0) return;

    // Try to handle as a command first; if not a command, show as chat
    if (!handleCommand(msg, "Web")) {
      Serial.print("[BLE] Received: ");
      Serial.println(msg);
    }
  }
};

// ==================== setup ====================
void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.println();
  Serial.println("========================================");
  Serial.println("  ESP32 BLE Chat — Starting up...");
  Serial.println("========================================");

  // Initialize BLE device
  BLEDevice::init("ESP32_BLE_Chat");

  // Request a larger MTU so longer messages fit in one packet
  BLEDevice::setMTU(512);

  // Create BLE server
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new ServerCallbacks());

  // Create the Nordic UART-like service
  BLEService *pService = pServer->createService(SERVICE_UUID);

  // TX characteristic (notify) — ESP32 sends data to the web page
  pTxCharacteristic = pService->createCharacteristic(
    CHARACTERISTIC_UUID_TX,
    BLECharacteristic::PROPERTY_NOTIFY
  );
  pTxCharacteristic->addDescriptor(new BLE2902());

  // RX characteristic (write) — web page sends data to ESP32
  BLECharacteristic *pRxCharacteristic = pService->createCharacteristic(
    CHARACTERISTIC_UUID_RX,
    BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR
  );
  pRxCharacteristic->setCallbacks(new RxCallbacks());

  // Start the service
  pService->start();

  // Start advertising so the web page can discover and connect
  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06);  // Helps with iPhone discovery
  pAdvertising->setMinPreferred(0x12);
  BLEDevice::startAdvertising();

  Serial.println("[BLE] BLE device name: ESP32_BLE_Chat");
  Serial.println("[BLE] Advertising started. Open the web page to connect.");
  Serial.println();
  Serial.println("[BLE] Type a message and press Enter to send to the web page.");
  Serial.println("[BLE] Commands: /ledon  /ledoff  /help");
  Serial.println();
}

// ==================== loop ====================
void loop() {
  // Read serial input: handle local commands or send to web page
  if (Serial.available()) {
    String msg = Serial.readStringUntil('\n');
    msg.trim();
    if (msg.length() > 0) {
      // Local commands work even without a web connection
      if (!handleCommand(msg, "Local")) {
        // Not a command -> send as a chat message to the web page
        if (deviceConnected) {
          sendViaBLE(msg);
          Serial.print("[BLE] Sent: ");
          Serial.println(msg);
        } else {
          Serial.println("[BLE] Not connected. Open the web page first.");
        }
      }
    }
  }

  delay(10);
}
