#include <WiFi.h>

// ==================== WiFi Credentials ====================
const char* ssid     = "ZNP_2.4G";      // Replace with your WiFi name
const char* password = "16881688";  // Replace with your WiFi password

// ==================== Variables ====================
unsigned long previousMillis = 0;
const long interval = 5000;  // Reconnect check interval (ms)

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("\n====================");
  Serial.println("ESP32 WiFi Tutorial");
  Serial.println("====================");

  // ---------- Step 1: Set WiFi mode to Station ----------
  WiFi.mode(WIFI_STA);
  Serial.println("WiFi mode set to STA (Station)");

  // ---------- Step 2: Begin connection ----------
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  // ---------- Step 3: Wait for connection (blocking) ----------
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  // ---------- Step 4: Check result ----------
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✅ WiFi Connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());           // e.g. 192.168.1.105
    Serial.print("MAC Address: ");
    Serial.println(WiFi.macAddress());        // e.g. 24:6F:28:A4:B2:C1
    Serial.print("RSSI (signal strength): ");
    Serial.print(WiFi.RSSI());
    Serial.println(" dBm");
  } else {
    Serial.println("\n❌ WiFi Connection Failed!");
    Serial.println("Please check your SSID and password.");
  }
}

void loop() {
  // ---------- Auto-reconnect logic ----------
  if (WiFi.status() != WL_CONNECTED) {
    unsigned long currentMillis = millis();
    if (currentMillis - previousMillis >= interval) {
      previousMillis = currentMillis;
      Serial.println("WiFi lost. Attempting to reconnect...");
      WiFi.reconnect();
    }
  }

  // Your main application code goes here
  // e.g. HTTP client, WebSocket, MQTT, etc.

  delay(100);
}