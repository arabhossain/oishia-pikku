#ifndef NTP_TIME_H
#define NTP_TIME_H

#include <WiFi.h>
#include <WiFiUdp.h>
#include <NTPClient.h>

// NTP configuration
extern const char* ntpServer;
extern const long gmtOffset_sec;

// External variable declaration
extern WiFiUDP ntpUDP;
extern NTPClient timeClient;

// Function declaration
void getNetTime(unsigned long& currentUnixTime);

#endif
