#include "WebServer.h"

// WiFi configuration
const char* sta_ssid      = "ZNP_2.4G";
const char* sta_password  = "16881688";
const char* ap_ssid       = "ESP32_AP";
const char* ap_password   = "12345678";
#define LED_BUILTIN 2
// WiFi server instance
WiFiServer server(80);

/**
 * Start AP mode (ESP32 uses softAP)
 */
void startAPMode() {
  Serial.println("\n📶 Starting AP hotspot: ESP32_AP");
  WiFi.softAP(ap_ssid, ap_password);
  delay(3000);
  Serial.print("AP IP address: ");
  Serial.println(WiFi.softAPIP());
}

/**
 * Handle web request
 * @param currentUnixTime Current timestamp
 * @param alarmHour Alarm hour
 * @param alarmMin Alarm minute
 * @param alarmOn Whether alarm is on
 * @param alarmRing Whether alarm is ringing
 * @param BUZZER_PIN Buzzer pin
 */
void handleWebRequest(int currentUnixTime, int& alarmHour, int& alarmMin, bool& alarmOn, bool& alarmRing, int BUZZER_PIN, float temperature, float humidity, bool& motorState) {
  // Web page processing
  WiFiClient client = server.available();
  if (client) {
    // Set short timeout to avoid blocking the main loop
    client.setTimeout(50);

    // Wait briefly for data, then read
    int waitCount = 0;
    while (client.available() == 0 && waitCount < 10) {
      delay(1);
      waitCount++;
    }

    if (client.available() == 0) {
      // No data received, close connection quickly
      client.stop();
      return;
    }

    String req = client.readStringUntil('\r');
    client.flush();

    // Print request information for debugging
    Serial.print("Request: "); Serial.println(req);

    if (req.indexOf("GET /H") != -1) {
      digitalWrite(LED_BUILTIN, HIGH);
      Serial.println("LED ON");
    }
    if (req.indexOf("GET /L") != -1) {
      digitalWrite(LED_BUILTIN, LOW);
      Serial.println("LED OFF");
    }

    // Motor control
    if (req.indexOf("GET /MOTOR_ON") != -1) {
      motorState = true;
      Serial.println("Motor ON");
    }
    if (req.indexOf("GET /MOTOR_OFF") != -1) {
      motorState = false;
      Serial.println("Motor OFF");
    }

    if (req.indexOf("GET /ALARM_OFF") != -1) {
      alarmRing = false;
      alarmOn = false;
      alarmHour = 0;
      alarmMin = 0;
      noTone(BUZZER_PIN); // Stop buzzer immediately

      // Print alarm off information to serial
      Serial.println("🔇 Alarm turned off and reset");
      Serial.print("alarmOn: "); Serial.println(alarmOn);
      Serial.print("alarmHour: "); Serial.println(alarmHour);
      Serial.print("alarmMin: "); Serial.println(alarmMin);
    }
    else if (req.indexOf("GET /ALARM?") != -1) {
      int hIndex = req.indexOf("h=");
      int mIndex = req.indexOf("m=");
      alarmHour = req.substring(hIndex+2, hIndex+4).toInt();
      alarmMin  = req.substring(mIndex+2, mIndex+4).toInt();
      alarmOn   = true;
      alarmRing = false;

      // Print alarm setting information to serial
      Serial.print("⏰ Alarm set: ");
      if(alarmHour<10) Serial.print("0"); Serial.print(alarmHour);
      Serial.print(":");
      if(alarmMin<10) Serial.print("0"); Serial.println(alarmMin);
    }

    int hh = (currentUnixTime % 86400L) / 3600;
    int mm = (currentUnixTime % 3600) / 60;

    // Web page interface
    client.println("HTTP/1.1 200 OK");
    client.println("Content-Type: text/html");
    client.println();
    client.println("<!DOCTYPE html>");
    client.println("<meta charset='utf-8'>");
    client.println("<body style='text-align:center;margin-top:40px'>");

    client.print("<h2>⏰ Current time: ");
    if(hh<10) client.print("0"); client.print(hh);
    client.print(":");
    if(mm<10) client.print("0"); client.print(mm);
    client.println("</h2>");

    client.print("<h3>Alarm status: ");
    if(alarmOn){
      if(alarmHour<10) client.print("0"); client.print(alarmHour);
      client.print(":");
      if(alarmMin<10) client.print("0"); client.print(alarmMin);
      client.print(" ✅");
    } else {
      client.print("Not set");
    }
    client.println("</h3>");

    // Temperature and humidity display
    client.println("<h3>Environment</h3>");
    client.print("<p>Temperature: ");
    client.print(temperature, 1);
    client.println(" °C</p>");
    client.print("<p>Humidity: ");
    client.print(humidity, 1);
    client.println(" %</p>");

    // Alarm input
    client.println("<h4>Set Alarm</h4>");
    client.println("<form action='ALARM' method='GET'>");
    client.println("Hour:<input name='h' maxlength='2' size='3' value='");
    if(alarmOn) {
      client.print(alarmHour);
    } else {
      client.print("8");
    }
    client.println("'> &nbsp;");
    client.println("Minute:<input name='m' maxlength='2' size='3' value='");
    if(alarmOn) {
      client.print(alarmMin);
    } else {
      client.print("30");
    }
    client.println("'>");
    client.println("<br><br>");
    client.println("<button type='submit'>Set Alarm</button> &nbsp;");
    client.println("<a href='/ALARM_OFF'><button type='button'>Turn Off Alarm</button></a>");
    client.println("</form>");

    client.println("<br><br><h4>💡 LED Control</h4>");
    // LED buttons - side by side
    client.println("<a href='/H'><button>LED ON</button></a> &nbsp;");
    client.println("<a href='/L'><button>LED OFF</button></a>");

    // Motor control
    client.println("<br><br><h4>🔧 Motor Control</h4>");
    client.println("<a href='/MOTOR_ON'><button>Motor ON</button></a> &nbsp;");
    client.println("<a href='/MOTOR_OFF'><button>Motor OFF</button></a>");

    client.println("</body>");
    client.stop();
  }
}
