#include "OLEDDisplay.h"

// OLED instance (I2C on ESP32: SDA=GPIO21, SCL=GPIO22)
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

/**
 * Initialize OLED display
 */
void oledInit() {
  // OLED initialization
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED initialization failed");
    while(1);
  }
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setCursor(0,0);
  display.println("OLED OK");
  display.display();
}

/**
 * Update OLED display
 * @param h Current hour
 * @param m Current minute
 * @param s Current second
 * @param alarmHour Alarm hour
 * @param alarmMin Alarm minute
 * @param alarmOn Whether alarm is on
 */
void updateOLED(int h, int m, int s, int alarmHour, int alarmMin, bool alarmOn, float temperature, float humidity) {
  display.clearDisplay();


  display.setTextSize(2);
  display.setCursor(0, 16);

  if(h<10) display.print("0"); display.print(h);
  display.print(":");
  if(m<10) display.print("0"); display.print(m);

  display.setTextSize(1);
  display.setCursor(65, 20);
  if(s<10) display.print("0"); display.print(s);

  if(alarmOn){
    display.setTextSize(1);
    display.setCursor(0,0);
    display.print("ALARM ");
    if(alarmHour<10) display.print("0"); display.print(alarmHour);
    display.print(":");
    if(alarmMin<10) display.print("0"); display.print(alarmMin);
  }

  // Display temperature and humidity at bottom with error detection
  display.setTextSize(1);
  display.setCursor(0, 40);
  display.print("T:");
  // Show ERR if reading is 0.0 (likely sensor failure)
  if (temperature == 0.0) {
    display.print("ERR");
  } else {
    display.print(temperature, 1);
    display.print("C");
  }

  display.setCursor(60, 40);
  display.print("H:");
  if (humidity == 0.0) {
    display.print("ERR");
  } else {
    display.print(humidity, 1);
    display.print("%");
  }

  display.display();
}
