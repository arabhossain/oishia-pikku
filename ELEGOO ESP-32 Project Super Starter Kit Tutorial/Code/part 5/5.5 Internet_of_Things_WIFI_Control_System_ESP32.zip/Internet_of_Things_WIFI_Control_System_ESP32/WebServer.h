#ifndef WEB_SERVER_H
#define WEB_SERVER_H

#include <WiFi.h>

// WiFi configuration
extern const char* sta_ssid;
extern const char* sta_password;
extern const char* ap_ssid;
extern const char* ap_password;

// External variable declaration
extern WiFiServer server;

// Function declaration
void startAPMode();
void handleWebRequest(int currentUnixTime, int& alarmHour, int& alarmMin, bool& alarmOn, bool& alarmRing, int BUZZER_PIN, float temperature, float humidity, bool& motorState);

#endif
