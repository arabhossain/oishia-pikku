#ifndef DHT_SENSOR_H
#define DHT_SENSOR_H

#include <dht_nonblocking.h>

// DHT sensor configuration (ESP32: GPIO4)
// GPIO4 verified working with standalone test
//
// === HARDWARE REQUIREMENTS ===
// 1. DHT11 VCC -> 3.3V (NOT 5V, ESP32 is 3.3V logic)
// 2. DHT11 GND -> ESP32 GND (MUST be common ground)
// 3. DHT11 DATA -> DHT_SENSOR_PIN (GPIO4)
// 4. 4.7kΩ pull-up resistor between DATA and VCC (CRITICAL!)
// 5. The dht_nonblocking library manages pinMode internally,
//    do NOT call pinMode() on the DHT pin externally
#define DHT_SENSOR_TYPE DHT_TYPE_11
#define DHT_SENSOR_PIN 4

// External variable declaration
extern DHT_nonblocking dht_sensor;

// Function declaration (uses pointer parameters, matching library convention)
bool measureEnvironment(float *temperature, float *humidity);

#endif