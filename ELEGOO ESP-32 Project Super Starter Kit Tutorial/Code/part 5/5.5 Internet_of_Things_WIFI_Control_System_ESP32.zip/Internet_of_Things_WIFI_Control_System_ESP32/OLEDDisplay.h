#ifndef OLED_DISPLAY_H
#define OLED_DISPLAY_H

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// OLED configuration
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

// External variable declaration
extern Adafruit_SSD1306 display;

// Function declaration
void oledInit();
void updateOLED(int h, int m, int s, int alarmHour, int alarmMin, bool alarmOn, float temperature, float humidity);

#endif
