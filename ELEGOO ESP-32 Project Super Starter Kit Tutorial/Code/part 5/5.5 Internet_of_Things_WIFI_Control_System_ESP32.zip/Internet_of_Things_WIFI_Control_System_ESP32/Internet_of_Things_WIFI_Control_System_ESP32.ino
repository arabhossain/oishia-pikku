#include <WiFi.h>
#include <Wire.h>
#include "OLEDDisplay.h"
#include "WebServer.h"
#include "NTPTime.h"
#include "DHTSensor.h"

// ==================== Buzzer (passive, PWM driven) ====================
#define BUZZER_PIN 18
#define BUZZER_FREQ 1000  // 1000Hz for passive buzzer

// ==================== Buzzer Button ====================
#define BUZZER_BTN_PIN 5

// ==================== Motor Control ====================
#define MOTOR_PIN 19

// ==================== LED ====================
#define LED_PIN 2

bool motorState = false;

// Time tracking
unsigned long currentUnixTime = 0;
unsigned long lastUpdateTime  = 0;

// ==================== Alarm Variables ====================
int alarmHour   = 0;
int alarmMin    = 0;
bool alarmOn    = false;
bool alarmRing  = false;

// ==================== Temperature and Humidity Variables ====================
float temperature = 0.0;
float humidity = 0.0;

void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(LED_PIN, OUTPUT);
  pinMode(MOTOR_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  digitalWrite(MOTOR_PIN, LOW);

  // Buzzer button (active low with internal pull-up)
  pinMode(BUZZER_BTN_PIN, INPUT_PULLUP);

  // Print DHT sensor configuration
  Serial.print("[DHT] Sensor type: DHT11, Pin: GPIO");
  Serial.println(DHT_SENSOR_PIN);
  Serial.println("[DHT] Waiting for sensor stabilization...");
  delay(2000);

  // I2C for OLED (ESP32 default: SDA=GPIO21, SCL=GPIO22)
  Wire.begin(21, 22);

  // OLED initialization
  oledInit();

  Serial.println("=== Getting NTP time at startup ===");
  getNetTime(currentUnixTime);
  startAPMode();
  server.begin();

  lastUpdateTime = millis();
}

void loop() {
  // Poll DHT sensor every loop iteration (state machine needs frequent calls)
  measureEnvironment(&temperature, &humidity);

  // Update time every second
  if (millis() - lastUpdateTime >= 1000) {
    lastUpdateTime = millis();
    currentUnixTime++;

    int h = (currentUnixTime % 86400L) / 3600;
    int m = (currentUnixTime % 3600) / 60;
    int s = currentUnixTime % 60;

    // Print time to serial
    Serial.print("Time: ");
    if(h<10) Serial.print("0"); Serial.print(h);
    Serial.print(":");
    if(m<10) Serial.print("0"); Serial.print(m);
    Serial.print(":");
    if(s<10) Serial.print("0"); Serial.println(s);

    // Update OLED display
    updateOLED(h, m, s, alarmHour, alarmMin, alarmOn, temperature, humidity);

    // Alarm trigger
    if(alarmOn && h == alarmHour && m == alarmMin && s == 0){
      alarmRing = true;
    }
  }

  // Handle web requests
  handleWebRequest(currentUnixTime, alarmHour, alarmMin, alarmOn, alarmRing, BUZZER_PIN, temperature, humidity, motorState);

  // Buzzer button: press to stop alarm
  static bool lastBtnState = HIGH;
  bool btnState = digitalRead(BUZZER_BTN_PIN);
  if (btnState == LOW && lastBtnState == HIGH) {
    delay(20); // simple debounce
    btnState = digitalRead(BUZZER_BTN_PIN);
    if (btnState == LOW) {
      if (alarmRing) {
        alarmRing = false;
        alarmOn = false;
        noTone(BUZZER_PIN);
        Serial.println("Button pressed: alarm stopped");
      }
    }
  }
  lastBtnState = btnState;

  // Alarm ringing (PWM tone, non-blocking)
  if (alarmRing) {
    tone(BUZZER_PIN, BUZZER_FREQ);
  } else {
    noTone(BUZZER_PIN);
  }

  // Motor control
  static bool lastMotorState = false;
  if(motorState != lastMotorState) {
    lastMotorState = motorState;
    digitalWrite(MOTOR_PIN, motorState ? HIGH : LOW);
    Serial.print("Motor state updated: ");
    Serial.println(motorState ? "ON" : "OFF");
  }
}
