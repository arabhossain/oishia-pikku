#include "NTPTime.h"
#include "WebServer.h"

// NTP configuration
const char* ntpServer = "ntp.ntsc.ac.cn";
const long gmtOffset_sec = 8 * 3600; // UTC+8 timezone

// NTP instance
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, ntpServer, gmtOffset_sec);

/**
 * Get network time
 * @param currentUnixTime Current timestamp reference
 */
void getNetTime(unsigned long& currentUnixTime) {
  // Disable WiFi modes before switching to STA
  WiFi.mode(WIFI_OFF);
  delay(500);
  WiFi.mode(WIFI_STA);

  Serial.print("Connecting to WiFi: ");
  Serial.println(sta_ssid);
  WiFi.begin(sta_ssid, sta_password);

  int timeout = 0;
  while (WiFi.status() != WL_CONNECTED && timeout < 40) {
    delay(500);
    Serial.print(".");
    timeout++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✅ WiFi connected successfully!");
    delay(1000);

    timeClient.begin();
    delay(1000);

    // Start NTP sync retry logic
    int ntpRetry = 0;
    bool ntp_ok = false;

    while (!ntp_ok && ntpRetry < 30) {
      ntpRetry++;
      Serial.print("NTP sync attempt " + String(ntpRetry) + "/30: ");
      ntp_ok = timeClient.update();

      if (ntp_ok) {
        currentUnixTime = timeClient.getEpochTime();
        Serial.println("✅ Success!");
        Serial.print("Current time: ");
        Serial.println(timeClient.getFormattedTime());
      } else {
        Serial.println("❌ Failed, retrying...");
        delay(2000);
      }
    }

    timeClient.end();

  } else {
    Serial.println("\n❌ WiFi connection failed, unable to sync NTP time");
    // Do not set default time, keep currentUnixTime unchanged
  }

  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(500);
}
