#include "DHTSensor.h"

// DHT sensor instance (library manages pinMode internally)
DHT_nonblocking dht_sensor(DHT_SENSOR_PIN, DHT_SENSOR_TYPE);

// Track consecutive failures for debug diagnostics
static int dht_fail_count = 0;

/**
 * Measure environment temperature and humidity
 * Matches the verified working example: timestamp updated ONLY after success.
 * If measurement fails, retry immediately (no delay penalty).
 * @param temperature Pointer to float for temperature value
 * @param humidity Pointer to float for humidity value
 * @return Whether measurement was successful
 */
bool measureEnvironment(float *temperature, float *humidity) {
  static unsigned long measurement_timestamp = millis();

  /* Measure once every three seconds. */
  if (millis() - measurement_timestamp > 3000ul) {
    if (dht_sensor.measure(temperature, humidity) == true) {
      // Update timestamp ONLY after successful measurement
      // (matches the working example behavior)
      measurement_timestamp = millis();
      dht_fail_count = 0;
      Serial.print("[DHT] OK -> T:");
      Serial.print(*temperature, 1);
      Serial.print("C, H:");
      Serial.print(*humidity, 1);
      Serial.println("%");
      return true;
    } else {
      // Failed: do NOT update timestamp, retry immediately on next call
      dht_fail_count++;
      Serial.print("[DHT] FAIL (count=");
      Serial.print(dht_fail_count);
      Serial.println(") -> Retrying...");
    }
  }

  return false;
}